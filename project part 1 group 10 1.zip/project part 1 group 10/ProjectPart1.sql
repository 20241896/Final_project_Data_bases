/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     10/17/2025 23:48:50                          */
/*==============================================================*/


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('ACTIONS') and o.name = 'FK_ACTIONS_ACTION_LI_LINEUPS')
alter table ACTIONS
   drop constraint FK_ACTIONS_ACTION_LI_LINEUPS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CLUB_MANAGER_HISTORY') and o.name = 'FK_CLUB_MAN_CLUB_CLUBS')
alter table CLUB_MANAGER_HISTORY
   drop constraint FK_CLUB_MAN_CLUB_CLUBS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CLUB_MANAGER_HISTORY') and o.name = 'FK_CLUB_MAN_MANAGER_MANAGERS')
alter table CLUB_MANAGER_HISTORY
   drop constraint FK_CLUB_MAN_MANAGER_MANAGERS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('LINEUPS') and o.name = 'FK_LINEUPS_CLUB_LINE_CLUBS')
alter table LINEUPS
   drop constraint FK_LINEUPS_CLUB_LINE_CLUBS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('LINEUPS') and o.name = 'FK_LINEUPS_MATCH_LIN_MATCHES')
alter table LINEUPS
   drop constraint FK_LINEUPS_MATCH_LIN_MATCHES
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('LINEUPS') and o.name = 'FK_LINEUPS_PLAYER_LI_PLAYERS')
alter table LINEUPS
   drop constraint FK_LINEUPS_PLAYER_LI_PLAYERS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MATCHES') and o.name = 'FK_MATCHES_AWAY_CLUB_CLUBS')
alter table MATCHES
   drop constraint FK_MATCHES_AWAY_CLUB_CLUBS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MATCHES') and o.name = 'FK_MATCHES_HOME_CLUB_CLUBS')
alter table MATCHES
   drop constraint FK_MATCHES_HOME_CLUB_CLUBS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MATCHES') and o.name = 'FK_MATCHES_SEASON_MA_SEASON')
alter table MATCHES
   drop constraint FK_MATCHES_SEASON_MA_SEASON
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PLAYERSTATISTICS') and o.name = 'FK_PLAYERST_LINEUP_PL_LINEUPS')
alter table PLAYERSTATISTICS
   drop constraint FK_PLAYERST_LINEUP_PL_LINEUPS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('SEASON') and o.name = 'FK_SEASON_COMPETITI_COMPETIT')
alter table SEASON
   drop constraint FK_SEASON_COMPETITI_COMPETIT
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('SEASON_CLUB') and o.name = 'FK_SEASON_C_CLUB_SEAS_CLUBS')
alter table SEASON_CLUB
   drop constraint FK_SEASON_C_CLUB_SEAS_CLUBS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('SEASON_CLUB') and o.name = 'FK_SEASON_C_SEASON_SE_SEASON')
alter table SEASON_CLUB
   drop constraint FK_SEASON_C_SEASON_SE_SEASON
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('TRANSFERS') and o.name = 'FK_TRANSFER_FROM_CLUB_CLUBS')
alter table TRANSFERS
   drop constraint FK_TRANSFER_FROM_CLUB_CLUBS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('TRANSFERS') and o.name = 'FK_TRANSFER_PLAYER_TR_PLAYERS')
alter table TRANSFERS
   drop constraint FK_TRANSFER_PLAYER_TR_PLAYERS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('TRANSFERS') and o.name = 'FK_TRANSFER_TO_CLUB_CLUBS')
alter table TRANSFERS
   drop constraint FK_TRANSFER_TO_CLUB_CLUBS
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('ACTIONS')
            and   name  = 'ACTION_LINEUPS_FK'
            and   indid > 0
            and   indid < 255)
   drop index ACTIONS.ACTION_LINEUPS_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('ACTIONS')
            and   type = 'U')
   drop table ACTIONS
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CLUBS')
            and   type = 'U')
   drop table CLUBS
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CLUB_MANAGER_HISTORY')
            and   name  = 'MANAGER_FK'
            and   indid > 0
            and   indid < 255)
   drop index CLUB_MANAGER_HISTORY.MANAGER_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CLUB_MANAGER_HISTORY')
            and   name  = 'CLUB_FK'
            and   indid > 0
            and   indid < 255)
   drop index CLUB_MANAGER_HISTORY.CLUB_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CLUB_MANAGER_HISTORY')
            and   type = 'U')
   drop table CLUB_MANAGER_HISTORY
go

if exists (select 1
            from  sysobjects
           where  id = object_id('COMPETITION')
            and   type = 'U')
   drop table COMPETITION
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('LINEUPS')
            and   name  = 'CLUB_LINEUPS_FK'
            and   indid > 0
            and   indid < 255)
   drop index LINEUPS.CLUB_LINEUPS_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('LINEUPS')
            and   name  = 'PLAYER_LINEUPS_FK'
            and   indid > 0
            and   indid < 255)
   drop index LINEUPS.PLAYER_LINEUPS_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('LINEUPS')
            and   name  = 'MATCH_LINEUPS_FK'
            and   indid > 0
            and   indid < 255)
   drop index LINEUPS.MATCH_LINEUPS_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('LINEUPS')
            and   type = 'U')
   drop table LINEUPS
go

if exists (select 1
            from  sysobjects
           where  id = object_id('MANAGERS')
            and   type = 'U')
   drop table MANAGERS
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MATCHES')
            and   name  = 'AWAY_CLUB_FK'
            and   indid > 0
            and   indid < 255)
   drop index MATCHES.AWAY_CLUB_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MATCHES')
            and   name  = 'HOME_CLUB_FK'
            and   indid > 0
            and   indid < 255)
   drop index MATCHES.HOME_CLUB_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MATCHES')
            and   name  = 'SEASON_MATCHES_FK'
            and   indid > 0
            and   indid < 255)
   drop index MATCHES.SEASON_MATCHES_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('MATCHES')
            and   type = 'U')
   drop table MATCHES
go

if exists (select 1
            from  sysobjects
           where  id = object_id('PLAYERS')
            and   type = 'U')
   drop table PLAYERS
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PLAYERSTATISTICS')
            and   name  = 'LINEUP_PLAYER_STATISTICS_FK'
            and   indid > 0
            and   indid < 255)
   drop index PLAYERSTATISTICS.LINEUP_PLAYER_STATISTICS_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('PLAYERSTATISTICS')
            and   type = 'U')
   drop table PLAYERSTATISTICS
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('SEASON')
            and   name  = 'COMPETITION_SEASON_FK'
            and   indid > 0
            and   indid < 255)
   drop index SEASON.COMPETITION_SEASON_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('SEASON')
            and   type = 'U')
   drop table SEASON
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('SEASON_CLUB')
            and   name  = 'SEASON_SEASON_CLUB_FK'
            and   indid > 0
            and   indid < 255)
   drop index SEASON_CLUB.SEASON_SEASON_CLUB_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('SEASON_CLUB')
            and   name  = 'CLUB_SEASON_FK'
            and   indid > 0
            and   indid < 255)
   drop index SEASON_CLUB.CLUB_SEASON_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('SEASON_CLUB')
            and   type = 'U')
   drop table SEASON_CLUB
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('TRANSFERS')
            and   name  = 'FROM_CLUB_FK'
            and   indid > 0
            and   indid < 255)
   drop index TRANSFERS.FROM_CLUB_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('TRANSFERS')
            and   name  = 'TO_CLUB_FK'
            and   indid > 0
            and   indid < 255)
   drop index TRANSFERS.TO_CLUB_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('TRANSFERS')
            and   name  = 'PLAYER_TRANSFER_FK'
            and   indid > 0
            and   indid < 255)
   drop index TRANSFERS.PLAYER_TRANSFER_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('TRANSFERS')
            and   type = 'U')
   drop table TRANSFERS
go

/*==============================================================*/
/* Table: ACTIONS                                               */
/*==============================================================*/
create table ACTIONS (
   ACTION_ID            int                  not null,
   LINEUP_ID            int                  not null,
   TYPE                 varchar(50)          null,
   MINUTE               datetime             null,
   SECOND               datetime             null,
   constraint PK_ACTIONS primary key nonclustered (ACTION_ID)
)
go

/*==============================================================*/
/* Index: ACTION_LINEUPS_FK                                     */
/*==============================================================*/
create index ACTION_LINEUPS_FK on ACTIONS (
LINEUP_ID ASC
)
go

/*==============================================================*/
/* Table: CLUBS                                                 */
/*==============================================================*/
create table CLUBS (
   CLUB_ID              int                  not null,
   NAME                 varchar(50)          null,
   COUNTRY              varchar(50)          null,
   YEAR                 int                  null,
   constraint PK_CLUBS primary key nonclustered (CLUB_ID)
)
go

/*==============================================================*/
/* Table: CLUB_MANAGER_HISTORY                                  */
/*==============================================================*/
create table CLUB_MANAGER_HISTORY (
   CLUB_MANAGER_ID      int                  not null,
   CLUB_ID              int                  not null,
   MANAGER_ID           int                  not null,
   START_DATE           datetime             null,
   END_DATE             datetime             null,
   constraint PK_CLUB_MANAGER_HISTORY primary key nonclustered (CLUB_MANAGER_ID)
)
go

/*==============================================================*/
/* Index: CLUB_FK                                               */
/*==============================================================*/
create index CLUB_FK on CLUB_MANAGER_HISTORY (
CLUB_ID ASC
)
go

/*==============================================================*/
/* Index: MANAGER_FK                                            */
/*==============================================================*/
create index MANAGER_FK on CLUB_MANAGER_HISTORY (
MANAGER_ID ASC
)
go

/*==============================================================*/
/* Table: COMPETITION                                           */
/*==============================================================*/
create table COMPETITION (
   COMPETITION_ID       int                  not null,
   NAME                 varchar(50)          null,
   COUNTRY              varchar(50)          null,
   TYPE                 varchar(50)          null,
   constraint PK_COMPETITION primary key nonclustered (COMPETITION_ID)
)
go

/*==============================================================*/
/* Table: LINEUPS                                               */
/*==============================================================*/
create table LINEUPS (
   LINEUP_ID            int                  not null,
   MATCH_ID             int                  not null,
   CLUB_ID              int                  not null,
   PLAYER_ID            int                  not null,
   POSITION             varchar(50)          null,
   STARTER_OR_SUBSTITUTTE bit                  null,
   MINUTES_PLAYED       datetime             null,
   constraint PK_LINEUPS primary key nonclustered (LINEUP_ID)
)
go

/*==============================================================*/
/* Index: MATCH_LINEUPS_FK                                      */
/*==============================================================*/
create index MATCH_LINEUPS_FK on LINEUPS (
MATCH_ID ASC
)
go

/*==============================================================*/
/* Index: PLAYER_LINEUPS_FK                                     */
/*==============================================================*/
create index PLAYER_LINEUPS_FK on LINEUPS (
PLAYER_ID ASC
)
go

/*==============================================================*/
/* Index: CLUB_LINEUPS_FK                                       */
/*==============================================================*/
create index CLUB_LINEUPS_FK on LINEUPS (
CLUB_ID ASC
)
go

/*==============================================================*/
/* Table: MANAGERS                                              */
/*==============================================================*/
create table MANAGERS (
   MANAGER_ID           int                  not null,
   DOB                  datetime             null,
   NATIONALITY          varchar(50)          null,
   NAME                 varchar(50)          null,
   constraint PK_MANAGERS primary key nonclustered (MANAGER_ID)
)
go

/*==============================================================*/
/* Table: MATCHES                                               */
/*==============================================================*/
create table MATCHES (
   MATCH_ID             int                  not null,
   HOME_CLUB_ID         int                  not null,
   COMPETITION_ID       int                  not null,
   SEASON_ID            int                  not null,
   AWAY_CLUB_ID         int                  not null,
   MATCHYDAY_NUMBER     int                  null,
   DATE                 datetime             null,
   ATTENDANCE           int                  null,
   constraint PK_MATCHES primary key nonclustered (MATCH_ID)
)
go

/*==============================================================*/
/* Index: SEASON_MATCHES_FK                                     */
/*==============================================================*/
create index SEASON_MATCHES_FK on MATCHES (
COMPETITION_ID ASC,
SEASON_ID ASC
)
go

/*==============================================================*/
/* Index: HOME_CLUB_FK                                          */
/*==============================================================*/
create index HOME_CLUB_FK on MATCHES (
HOME_CLUB_ID ASC
)
go

/*==============================================================*/
/* Index: AWAY_CLUB_FK                                          */
/*==============================================================*/
create index AWAY_CLUB_FK on MATCHES (
AWAY_CLUB_ID ASC
)
go

/*==============================================================*/
/* Table: PLAYERS                                               */
/*==============================================================*/
create table PLAYERS (
   PLAYER_ID            int                  not null,
   NAME                 varchar(50)          null,
   DOB                  datetime             null,
   HEIGHT               smallint             null,
   WEIGHT               smallint             null,
   CURRENTMARKETVALUE   money                null,
   constraint PK_PLAYERS primary key nonclustered (PLAYER_ID)
)
go

/*==============================================================*/
/* Table: PLAYERSTATISTICS                                      */
/*==============================================================*/
create table PLAYERSTATISTICS (
   STAT_ID              int                  not null,
   LINEUP_ID            int                  not null,
   MINUTES_PLAYED       datetime             null,
   PASSES_COMPLETED     int                  null,
   SHOTS_ON_TARGET      int                  null,
   GOALS_SCORED         int                  null,
   constraint PK_PLAYERSTATISTICS primary key nonclustered (STAT_ID)
)
go

/*==============================================================*/
/* Index: LINEUP_PLAYER_STATISTICS_FK                           */
/*==============================================================*/
create index LINEUP_PLAYER_STATISTICS_FK on PLAYERSTATISTICS (
LINEUP_ID ASC
)
go

/*==============================================================*/
/* Table: SEASON                                                */
/*==============================================================*/
create table SEASON (
   COMPETITION_ID       int                  not null,
   SEASON_ID            int                  not null,
   END_DATE             datetime             null,
   START_DATE           datetime             null,
   constraint PK_SEASON primary key nonclustered (COMPETITION_ID, SEASON_ID)
)
go

/*==============================================================*/
/* Index: COMPETITION_SEASON_FK                                 */
/*==============================================================*/
create index COMPETITION_SEASON_FK on SEASON (
COMPETITION_ID ASC
)
go

/*==============================================================*/
/* Table: SEASON_CLUB                                           */
/*==============================================================*/
create table SEASON_CLUB (
   CLUB_ID              int                  not null,
   COMPETITION_ID       int                  not null,
   SEASON_ID            int                  not null,
   TITLES_WON           varchar(20)          null,
   POINTS               int                  null,
   RANK                 smallint             null,
   MATCHES_PLAYED       varchar(50)          null,
   constraint PK_SEASON_CLUB primary key (COMPETITION_ID, CLUB_ID, SEASON_ID)
)
go

/*==============================================================*/
/* Index: CLUB_SEASON_FK                                        */
/*==============================================================*/
create index CLUB_SEASON_FK on SEASON_CLUB (
CLUB_ID ASC
)
go

/*==============================================================*/
/* Index: SEASON_SEASON_CLUB_FK                                 */
/*==============================================================*/
create index SEASON_SEASON_CLUB_FK on SEASON_CLUB (
COMPETITION_ID ASC,
SEASON_ID ASC
)
go

/*==============================================================*/
/* Table: TRANSFERS                                             */
/*==============================================================*/
create table TRANSFERS (
   TRANSFER_ID          int                  not null,
   TO_CLUB_ID           int                  not null,
   FROM_CLUB_ID         int                  not null,
   PLAYER_ID            int                  not null,
   TRANSFER_FEE         money                null,
   CONTRACT_LENGTH      int                  null,
   TRANSFER_DATE        datetime             null,
   constraint PK_TRANSFERS primary key nonclustered (TRANSFER_ID)
)
go

/*==============================================================*/
/* Index: PLAYER_TRANSFER_FK                                    */
/*==============================================================*/
create index PLAYER_TRANSFER_FK on TRANSFERS (
PLAYER_ID ASC
)
go

/*==============================================================*/
/* Index: TO_CLUB_FK                                            */
/*==============================================================*/
create index TO_CLUB_FK on TRANSFERS (
TO_CLUB_ID ASC
)
go

/*==============================================================*/
/* Index: FROM_CLUB_FK                                          */
/*==============================================================*/
create index FROM_CLUB_FK on TRANSFERS (
FROM_CLUB_ID ASC
)
go

alter table ACTIONS
   add constraint FK_ACTIONS_ACTION_LI_LINEUPS foreign key (LINEUP_ID)
      references LINEUPS (LINEUP_ID)
go

alter table CLUB_MANAGER_HISTORY
   add constraint FK_CLUB_MAN_CLUB_CLUBS foreign key (CLUB_ID)
      references CLUBS (CLUB_ID)
go

alter table CLUB_MANAGER_HISTORY
   add constraint FK_CLUB_MAN_MANAGER_MANAGERS foreign key (MANAGER_ID)
      references MANAGERS (MANAGER_ID)
go

alter table LINEUPS
   add constraint FK_LINEUPS_CLUB_LINE_CLUBS foreign key (CLUB_ID)
      references CLUBS (CLUB_ID)
go

alter table LINEUPS
   add constraint FK_LINEUPS_MATCH_LIN_MATCHES foreign key (MATCH_ID)
      references MATCHES (MATCH_ID)
go

alter table LINEUPS
   add constraint FK_LINEUPS_PLAYER_LI_PLAYERS foreign key (PLAYER_ID)
      references PLAYERS (PLAYER_ID)
go

alter table MATCHES
   add constraint FK_MATCHES_AWAY_CLUB_CLUBS foreign key (AWAY_CLUB_ID)
      references CLUBS (CLUB_ID)
go

alter table MATCHES
   add constraint FK_MATCHES_HOME_CLUB_CLUBS foreign key (HOME_CLUB_ID)
      references CLUBS (CLUB_ID)
go

alter table MATCHES
   add constraint FK_MATCHES_SEASON_MA_SEASON foreign key (COMPETITION_ID, SEASON_ID)
      references SEASON (COMPETITION_ID, SEASON_ID)
go

alter table PLAYERSTATISTICS
   add constraint FK_PLAYERST_LINEUP_PL_LINEUPS foreign key (LINEUP_ID)
      references LINEUPS (LINEUP_ID)
go

alter table SEASON
   add constraint FK_SEASON_COMPETITI_COMPETIT foreign key (COMPETITION_ID)
      references COMPETITION (COMPETITION_ID)
go

alter table SEASON_CLUB
   add constraint FK_SEASON_C_CLUB_SEAS_CLUBS foreign key (CLUB_ID)
      references CLUBS (CLUB_ID)
go

alter table SEASON_CLUB
   add constraint FK_SEASON_C_SEASON_SE_SEASON foreign key (COMPETITION_ID, SEASON_ID)
      references SEASON (COMPETITION_ID, SEASON_ID)
go

alter table TRANSFERS
   add constraint FK_TRANSFER_FROM_CLUB_CLUBS foreign key (FROM_CLUB_ID)
      references CLUBS (CLUB_ID)
go

alter table TRANSFERS
   add constraint FK_TRANSFER_PLAYER_TR_PLAYERS foreign key (PLAYER_ID)
      references PLAYERS (PLAYER_ID)
go

alter table TRANSFERS
   add constraint FK_TRANSFER_TO_CLUB_CLUBS foreign key (TO_CLUB_ID)
      references CLUBS (CLUB_ID)
go

